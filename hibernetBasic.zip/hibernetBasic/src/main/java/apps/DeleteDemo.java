package apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import entities.Emp;

public class DeleteDemo {

	public static void main(String[] args) {
		//session factory build
		Configuration conf = new Configuration().configure();
		SessionFactory sf =  conf.buildSessionFactory();
		System.out.println("Session factory created");
		
		//short lived - dialog with database
		Session session = sf.openSession();	
		
		Transaction tr = session.beginTransaction();
		//find and get the record - object
		Emp emp = session.find(Emp.class, 7788);
		session.remove(emp);
		System.out.println("emp instance deleted");
		
		tr.commit();
		session.close();
		sf.close();
		// TODO Auto-generated method stub

	}

}

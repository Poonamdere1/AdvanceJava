package apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import entities.Emp;

public class UpdateDemo {

	public static void main(String[] args) {
		
		Configuration conf = new Configuration().configure();
		SessionFactory sf =  conf.buildSessionFactory();
		System.out.println("Session factory created");
		
		
		Session session = sf.openSession();	
		
		Transaction tr = session.beginTransaction();
		
		Emp emp = session.find(Emp.class, 6666);
		emp.setJob("Analyst");
		session.merge(emp);
		System.out.println("emp instance updated");
		
		tr.commit();
		session.close();
		sf.close();

	}

}

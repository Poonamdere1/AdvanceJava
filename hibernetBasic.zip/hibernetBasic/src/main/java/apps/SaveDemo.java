package apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import entities.Emp;

public class SaveDemo {

	public static void main(String[] args) {
		Configuration conf=new Configuration().configure();
		SessionFactory sf=conf.buildSessionFactory();
		System.out.println("Session factory is created");
		Session session=sf.openSession();
		Emp emp = new Emp(14000,"Rahul","Manager",7698,null,10000.0f, 1000.0f,20);		
		Transaction tr = session.beginTransaction();
		session.persist(emp);   //save operation - insert query
		tr.commit();
		System.out.println("Emp instance saved");
		session.close();
		sf.close();
		
		
	}

}


public class ExecuteSimpleQuery {

	public static void main(String[] args) {
	
		
		

	}

}

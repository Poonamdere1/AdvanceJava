package callable_Statement;

import java.sql.*;

public class SortByName{

    public static void main(String[] args) {

        try {

            Connection con =
                    DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/ac26",
                            "root",
                            "root");

            CallableStatement cs =
                    con.prepareCall("{call UpdateSalary(?,?)}");

            cs.setInt(1, 101);
            cs.setDouble(2, 10);

            cs.execute();

            System.out.println("Salary Updated Successfully");

            con.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
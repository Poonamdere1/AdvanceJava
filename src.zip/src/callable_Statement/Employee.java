package callable_Statement;

public class Employee implements Comparable<Employee> {

	int empno;
	String ename;
	double sal;
	
	public Employee(int empno, String ename,double sal) {
		this.empno=empno;
		this.ename=ename;
		this.sal=sal;
	}
	
	
	
	public int getEmpno() {
		return empno;
	}



	public void setEmpno(int empno) {
		this.empno = empno;
	}



	public String getEname() {
		return ename;
	}



	public void setEname(String ename) {
		this.ename = ename;
	}



	public double getSal() {
		return sal;
	}



	public void setSal(double sal) {
		this.sal = sal;
	}



	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", ename=" + ename + ", sal=" + sal + "]";
	}



	@Override
	public int compareTo(Employee o) {
	
		return this.ename.compareTo(o.ename);
	}

}

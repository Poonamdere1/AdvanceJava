package callable_Statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class EmployeeDisplay {
	 public static void main(String[] args) {
		 
		 ArrayList<Employee> empList = new ArrayList<>();

	        try {
	            Connection con = DriverManager.getConnection(
	                    "jdbc:mysql://localhost:3306/ac26",
	                    "root",
	                    "root");

	            Statement st = con.createStatement();

	            ResultSet rs = st.executeQuery("select * from emp");

	            while(rs.next()) {

	                Employee e = new Employee(
	                        rs.getInt("empno"),
	                        rs.getString("ename"),
	                        rs.getDouble("sal"));

	                empList.add(e);
	            }

	            con.close();

	            System.out.println("Employees Loaded Successfully");
	            for(Employee e : empList) {
	                System.out.println(e);
	            }

	        } catch(Exception e) {
	            e.printStackTrace();
	        }

}
}

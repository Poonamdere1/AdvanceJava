package Day1_Assingment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class SearchEmployee {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee ID");
		int id=sc.nextInt();
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ac26","root","root");
		PreparedStatement ps=con.prepareStatement("select * from emp where empno=?");
		    ps.setInt(1, id);
		    ResultSet rs=ps.executeQuery();
		    if(rs.next()) {
		    	 System.out.println(
	                        rs.getInt("empno") + " "
	                        + rs.getString("ename") + " "
	                        + rs.getDouble("sal"));
		    	
		    }
		    else {
		    	System.out.println("Employee Does not exit");
		    	
		    }
		
		con.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}

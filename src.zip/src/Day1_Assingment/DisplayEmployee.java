package Day1_Assingment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DisplayEmployee {

	public static void main(String[] args) {
		

		  String url = "jdbc:mysql://localhost:3306/ac26";
	        String user = "root";
	        String password = "root";

	        try {
	            Connection con = DriverManager.getConnection(url, user, password);

	            String sql = "SELECT * FROM emp";

	            Statement st = con.createStatement();

	            ResultSet rs = st.executeQuery(sql);

	            while(rs.next()) {

	                System.out.println(
	                        rs.getInt("empno") + " "
	                        + rs.getString("ename") + " "
	                        + rs.getString("job") + " "
	                        + rs.getDouble("sal")
	                );
	            }
	            

	            con.close();

	        } catch(Exception e) {
	            e.printStackTrace();
	        }
	    }
	}
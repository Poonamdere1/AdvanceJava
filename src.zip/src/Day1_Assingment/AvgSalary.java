package Day1_Assingment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class AvgSalary {

	public static void main(String[] args) {
	
		try {
			Connection con =DriverManager.getConnection( "jdbc:mysql://localhost:3306/ac26",
                    "root",
                    "root");
			String query="select d.dname, avg(e.sal) avg_salary " +
                    "from emp e join dept d " +
                    "on e.deptno=d.deptno " +
                    "group by d.dname " +
                    "order by avg_salary desc";
			  Statement st = con.createStatement();
	            ResultSet rs = st.executeQuery(query);
	            while(rs.next()) {
	            	 System.out.println(
	                         rs.getString("dname") + " "
	                         + rs.getDouble("avg_salary"));
	            }
        con.close();
	}
		catch(Exception e) {
            e.printStackTrace();
        }
	}

}

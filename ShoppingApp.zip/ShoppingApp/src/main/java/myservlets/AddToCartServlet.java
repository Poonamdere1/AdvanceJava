package myservlets;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/addtocart")
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	//business logic
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int pid = Integer.parseInt(request.getParameter("selectedproduct"));
		HttpSession session = request.getSession();
		List<Integer> products = (List<Integer>)session.getAttribute("cart");
		//only for first selection
		if(products == null) {
			products = new ArrayList<>();			
		}
		products.add(pid);   //one new element will be added in the arraylist
		session.setAttribute("cart", products);
		out.print("<p> Product with "+pid+" is addeed in the cart </p>");
		out.print("<p> There are "+products.size() +" product(s) in the cart </p>");
		out.print("<p> <a href='home'> Go back for more selection </a> </p>");
		out.print("<p> <a href='viewcart'> View Cart </a> </p>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

package myservlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/getproducts")
public class GetProductsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	public void init(ServletConfig config) throws ServletException {
		super.init(config);  //imp
		con = (Connection)config.getServletContext().getAttribute("jdbccon");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		int cid = Integer.parseInt(request.getParameter("catid"));
		PreparedStatement ps =null;
		ResultSet rs = null;
		RequestDispatcher rd = request.getRequestDispatcher("/header");
		rd.include(request, response);
		try {
			ps = con.prepareStatement("select * from product where cat_id = ?");
			ps.setInt(1, cid);
			rs = ps.executeQuery();
			out.print("<form action='addtocart' >");
			out.print("Select product : ");
			out.print("<select name='selectedproduct'>");
			while(rs.next()) {
				out.print("<option value='"+rs.getInt(1)+"'>"+ rs.getString(2)+ "</option>");
			}
			out.print("</select> <br/>");
			out.print("<input type='submit' value='Add To Cart' />");
			out.print("</form>");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}

package myservlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);  //imp
		con = (Connection)config.getServletContext().getAttribute("jdbccon");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	//business logic
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		Statement stmt = null;
		ResultSet rs= null;
		//rd - include - header
		RequestDispatcher rd = request.getRequestDispatcher("/header");
		rd.include(request, response);
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from category");
			while(rs.next()) {
				out.print("<a href='getproducts?catid="+rs.getInt(1)+"'> "+rs.getString(2)+"</a> <br/>");
			}			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}

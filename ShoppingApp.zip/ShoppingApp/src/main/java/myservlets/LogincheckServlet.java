package myservlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entities.User;

@WebServlet("/logincheck")
public class LogincheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;   //create - init, use - doPost

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);		
		con = (Connection)config.getServletContext().getAttribute("jdbccon");
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//business logic
		//reading req parameters
		//connection to database
		//create query - prepared statement
		//next() - true/false		
		PrintWriter out = response.getWriter();
		String uid = request.getParameter("uid");
		String pwd = request.getParameter("pwd");
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = con.prepareStatement("select * from users where u_id = ? and password = ?");
			ps.setString(1, uid);
			ps.setString(2, pwd);
			rs = ps.executeQuery();
			if(rs.next()) {
				//out.print("Login successful - JDBC");
				//dispatch request - success
				//read user info - keep it in the session
				User user = new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(5),rs.getString(6),rs.getString(7));
				HttpSession session = request.getSession();
				session.setAttribute("loggedinuser", user);
				RequestDispatcher rd = request.getRequestDispatcher("/home");
				rd.forward(request, response);    ///success - doPost
			}
			else {
				out.print("Login failed - JDBC");
				//redirect to login.html
				//response.sendRedirect("/MoreOnServlets/login.html");
			}			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				rs.close();
				ps.close();
				//con.close(); - destroy method
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
	}

}

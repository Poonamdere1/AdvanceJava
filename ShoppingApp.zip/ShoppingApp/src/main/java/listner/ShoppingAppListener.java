package listner;

import java.sql.Connection;
import java.sql.DriverManager;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class ShoppingAppListener implements ServletContextListener {

	Connection con;
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		try {
			con.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		//db connection
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String jdbcurl = "jdbc:mysql://localhost:3306/shoppingdb";
			con = DriverManager.getConnection(jdbcurl, "root", "root");
			System.out.println("connection established");
			sce.getServletContext().setAttribute("jdbccon", con);
			System.out.println("con is set as ctx level attribute");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	

}

<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
     <h1> Login Form </h1>   
    <form action="http://localhost:8080/ShoppingApp/logincheck" method="post">
    	Enter uid : <input type="text" name="uid" />
    	<br/>
    	Enter pwd : <input type="password" name="pwd" />
    	<br/>
    	<input type="submit" value="LOGIN" />
    </form>
    
    <!--  request body -->   
    
    
    
    <a href="#"> New User? Register here </a>
</body>
</html>